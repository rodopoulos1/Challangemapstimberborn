Rodo Challange Maps
Mode: EASY

NEEDED:

Play on MEDIUM

Play with Folktails

First map for the timeline of Rodo Challange Maps

If you have a suggestion enter on my GITHUB on the part of the issues for a feedback


Simply place the .timber file into your \Documents\Timberborn\Maps\ folder, if you have downloaded this manually.